mkdir -p build
rm -f debian/changelog
dch --package pywebdriver --newversion 20230707 --create -m "automatic build"
debuild
cp ../pywebdriver_* /build
